-- WEEK 2: SQL FOR DATA ANALYSIS
-- Internship Assignment
-- Database: MySQL 8+

DROP DATABASE IF EXISTS week2_sql_analysis;
CREATE DATABASE week2_sql_analysis;
USE week2_sql_analysis;

-- =========================
-- 1. CREATE TABLES
-- =========================

CREATE TABLE customers (
    customer_id INT PRIMARY KEY,
    customer_name VARCHAR(100) NOT NULL,
    city VARCHAR(50),
    country VARCHAR(50)
);

CREATE TABLE orders (
    order_id INT PRIMARY KEY,
    customer_id INT NOT NULL,
    order_date DATE NOT NULL,
    order_status VARCHAR(20),
    order_amount DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

-- =========================
-- 2. SAMPLE DATA
-- =========================

INSERT INTO customers (customer_id, customer_name, city, country) VALUES
(1, 'Rahul Sharma', 'Bangalore', 'India'),
(2, 'Priya Singh', 'Mumbai', 'India'),
(3, 'Arjun Kumar', 'Delhi', 'India'),
(4, 'Sneha Patel', 'Pune', 'India'),
(5, 'Vikram Rao', 'Hyderabad', 'India'),
(6, 'Ananya Das', 'Chennai', 'India'),
(7, 'Kiran Joshi', 'Mysore', 'India'),
(8, 'Neha Verma', 'Bangalore', 'India');

INSERT INTO orders
(order_id, customer_id, order_date, order_status, order_amount) VALUES
(101, 1, '2026-01-05', 'Completed', 2500.00),
(102, 1, '2026-01-15', 'Completed', 1800.00),
(103, 2, '2026-01-07', 'Completed', 4200.00),
(104, 2, '2026-02-10', 'Completed', 1500.00),
(105, 3, '2026-01-20', 'Cancelled', 3200.00),
(106, 3, '2026-02-02', 'Completed', 5100.00),
(107, 4, '2026-02-05', 'Completed', 2800.00),
(108, 4, '2026-02-18', 'Completed', 3500.00),
(109, 5, '2026-01-12', 'Completed', 6200.00),
(110, 5, '2026-02-15', 'Completed', 4100.00),
(111, 6, '2026-02-20', 'Completed', 1900.00),
(112, 7, '2026-02-22', 'Completed', 7300.00),
(113, 8, '2026-02-25', 'Completed', 2100.00),
(114, 8, '2026-03-01', 'Completed', 2700.00);

-- =========================
-- 3. BASIC SELECT / WHERE
-- =========================

-- Q1. Display all customers.
SELECT * FROM customers;

-- Q2. Display customers from Bangalore.
SELECT *
FROM customers
WHERE city = 'Bangalore';

-- Q3. Display completed orders above Rs. 3000.
SELECT *
FROM orders
WHERE order_status = 'Completed'
  AND order_amount > 3000;

-- =========================
-- 4. ORDER BY
-- =========================

-- Q4. Display orders from highest to lowest amount.
SELECT *
FROM orders
ORDER BY order_amount DESC;

-- Q5. Display customers alphabetically.
SELECT *
FROM customers
ORDER BY customer_name ASC;

-- =========================
-- 5. AGGREGATE FUNCTIONS
-- =========================

-- Q6. Find total order revenue from completed orders.
SELECT SUM(order_amount) AS total_revenue
FROM orders
WHERE order_status = 'Completed';

-- Q7. Find average completed order value.
SELECT ROUND(AVG(order_amount), 2) AS average_order_value
FROM orders
WHERE order_status = 'Completed';

-- Q8. Count total orders.
SELECT COUNT(*) AS total_orders
FROM orders;

-- Q9. Count completed orders.
SELECT COUNT(*) AS completed_orders
FROM orders
WHERE order_status = 'Completed';

-- =========================
-- 6. GROUP BY
-- =========================

-- Q10. Find number of orders for each customer.
SELECT
    customer_id,
    COUNT(*) AS total_orders
FROM orders
GROUP BY customer_id
ORDER BY total_orders DESC;

-- Q11. Find total completed spending for each customer.
SELECT
    customer_id,
    SUM(order_amount) AS total_spent
FROM orders
WHERE order_status = 'Completed'
GROUP BY customer_id
ORDER BY total_spent DESC;

-- Q12. Find average completed order value for each customer.
SELECT
    customer_id,
    ROUND(AVG(order_amount), 2) AS average_order_value
FROM orders
WHERE order_status = 'Completed'
GROUP BY customer_id
ORDER BY average_order_value DESC;

-- =========================
-- 7. JOINS
-- =========================

-- Q13. Show customer names with their orders.
SELECT
    c.customer_name,
    c.city,
    o.order_id,
    o.order_date,
    o.order_status,
    o.order_amount
FROM customers c
JOIN orders o
    ON c.customer_id = o.customer_id
ORDER BY o.order_date;

-- Q14. Show total completed spending by customer name.
SELECT
    c.customer_name,
    c.city,
    ROUND(SUM(o.order_amount), 2) AS total_spent
FROM customers c
JOIN orders o
    ON c.customer_id = o.customer_id
WHERE o.order_status = 'Completed'
GROUP BY c.customer_id, c.customer_name, c.city
ORDER BY total_spent DESC;

-- =========================
-- 8. TOP CUSTOMERS
-- =========================

-- Q15. Find the top 5 customers by completed spending.
SELECT
    c.customer_id,
    c.customer_name,
    ROUND(SUM(o.order_amount), 2) AS total_spent
FROM customers c
JOIN orders o
    ON c.customer_id = o.customer_id
WHERE o.order_status = 'Completed'
GROUP BY c.customer_id, c.customer_name
ORDER BY total_spent DESC
LIMIT 5;

-- =========================
-- 9. SUBQUERIES
-- =========================

-- Q16. Find orders whose amount is greater than
-- the average completed order value.
SELECT *
FROM orders
WHERE order_status = 'Completed'
  AND order_amount > (
      SELECT AVG(order_amount)
      FROM orders
      WHERE order_status = 'Completed'
  )
ORDER BY order_amount DESC;

-- Q17. Find customers whose completed spending is
-- greater than the average customer spending.
SELECT
    c.customer_name,
    ROUND(SUM(o.order_amount), 2) AS total_spent
FROM customers c
JOIN orders o
    ON c.customer_id = o.customer_id
WHERE o.order_status = 'Completed'
GROUP BY c.customer_id, c.customer_name
HAVING SUM(o.order_amount) > (
    SELECT AVG(customer_total)
    FROM (
        SELECT SUM(order_amount) AS customer_total
        FROM orders
        WHERE order_status = 'Completed'
        GROUP BY customer_id
    ) AS customer_totals
)
ORDER BY total_spent DESC;

-- =========================
-- 10. CASE STATEMENT
-- =========================

-- Q18. Categorize each completed order.
SELECT
    order_id,
    order_amount,
    CASE
        WHEN order_amount >= 5000 THEN 'High Value'
        WHEN order_amount >= 2500 THEN 'Medium Value'
        ELSE 'Low Value'
    END AS order_category
FROM orders
WHERE order_status = 'Completed'
ORDER BY order_amount DESC;

-- Q19. Categorize customers based on total spending.
SELECT
    c.customer_name,
    ROUND(SUM(o.order_amount), 2) AS total_spent,
    CASE
        WHEN SUM(o.order_amount) >= 8000 THEN 'Premium'
        WHEN SUM(o.order_amount) >= 5000 THEN 'Regular'
        ELSE 'Occasional'
    END AS customer_category
FROM customers c
JOIN orders o
    ON c.customer_id = o.customer_id
WHERE o.order_status = 'Completed'
GROUP BY c.customer_id, c.customer_name
ORDER BY total_spent DESC;

-- =========================
-- 11. DATA ANALYSIS SUMMARY
-- =========================

-- Q20. Overall business summary.
SELECT
    COUNT(*) AS completed_orders,
    ROUND(SUM(order_amount), 2) AS total_revenue,
    ROUND(AVG(order_amount), 2) AS average_order_value,
    ROUND(MAX(order_amount), 2) AS highest_order_value,
    ROUND(MIN(order_amount), 2) AS lowest_order_value
FROM orders
WHERE order_status = 'Completed';

-- =========================
-- END OF WEEK 2 ASSIGNMENT
-- =========================

# Week 2 - SQL for Data Analysis

## Internship Assignment

This project covers the Week 2 SQL topics:

- SELECT
- WHERE
- GROUP BY
- ORDER BY
- SUM, AVG, COUNT, MIN, MAX
- JOIN
- Subqueries
- CASE statements
- Top customers
- Average order value
- Basic business analysis

## Database

The project uses **MySQL 8+**.

### Tables

1. `customers`
   - customer_id
   - customer_name
   - city
   - country

2. `orders`
   - order_id
   - customer_id
   - order_date
   - order_status
   - order_amount

## How to Run

1. Open MySQL Workbench or another MySQL client.
2. Open `week2_sql_assignment.sql`.
3. Run the complete script.
4. The script creates the database `week2_sql_analysis`.
5. Execute the queries individually to view the results.

## Main Analysis

The assignment answers questions such as:

- Which customers are from Bangalore?
- What is the total revenue?
- What is the average order value?
- Which customers spend the most?
- What are the top 5 customers?
- Which orders are above the average order value?
- How can customers/orders be categorized using CASE?
- What is the overall business summary?

## GitHub Submission

Suggested repository name:

`week2-sql-data-analysis`

Suggested files:

```text
week2-sql-data-analysis/
├── week2_sql_assignment.sql
└── README.md
```
